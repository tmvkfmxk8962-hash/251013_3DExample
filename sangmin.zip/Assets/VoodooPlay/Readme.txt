Sci fi Drone free model

Thanks for downloading the free model, hope you enjoy it!
check out other assets here:

https://assetstore.unity.com/publishers/9657

